import React, { Component } from 'react'
import Foot from '@@/Foot'


export default class cart extends Component {
    render() {
        return (
            <div className="home">
               <div className="section">
                 购物车 
               </div>
               <Foot />
            </div>
        )
    }
}

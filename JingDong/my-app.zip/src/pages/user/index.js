import React, { Component } from 'react'
import Foot from '@@/Foot'

export default class user extends Component {
    render() {
        return (
            <div className="home">
               <div className="section">
                 我的
               </div>
               <Foot />
            </div>
        )
    }
}

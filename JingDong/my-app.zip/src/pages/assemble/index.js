import React, { Component } from 'react'
import Foot from '@/components/Foot'

export default class assemble extends Component {
    render() {
        return (
            <div className="home">
               <div className="section">
                 拼购
               </div>
               <Foot />
            </div>
        )
    }
}
